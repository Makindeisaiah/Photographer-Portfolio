<footer class="footer clearfix" data-overlay-darkgray="8">
        <div class="container">
            <!-- Second footer -->
            <div class="second-footer">
                <div class="row">
                    <div class="col-md-4 widget-area">
                        <div class="widget clearfix">
                            <div class="footer-logo"> <img class="img-fluid" src="img/viruslogo5.png" alt=""> </div>
                            <div class="widget-text">
                                <p>Virus Shot we got you coverd</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 widget-area">
                        <div class="widget clearfix usful-links">
                            <h3 class="widget-title">Quick Links</h3>
                            <ul>
                                <li><a href="about.php">About</a></li>
                                <li><a href="services.php">Services</a></li>
                                <li><a href="works.php">Works</a></li>
                                <li><a href="blog.php">Blog</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 widget-area">
                        <div class="widget clearfix">
                            <h3 class="widget-title">Contact</h3>
                            <div class="featured-icon-box icon-align-before-content icon-ver_align-top style1">
                                <div class="featured-icon">
                                    <div class="ttm-icon ttm-icon_element-onlytxt ttm-icon_element-color-skincolor ttm-icon_element-size-xs"> <i class="ti-mobile"></i> </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-desc">
                                        <a href="tel:+234 813 458 7909">+234 813 458 7909</a>
                                    </div>
                                </div>
                            </div>
                            <div class="featured-icon-box icon-align-before-content icon-ver_align-top style1">
                                <div class="featured-icon">
                                    <div class="ttm-icon ttm-icon_element-onlytxt ttm-icon_element-color-skincolor ttm-icon_element-size-xs"> <i class="ti-email"></i> </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-desc">
                                        <a href="mailto:ayomideisrael@gmail.com">Ayomideisrael@gmail.com</a>
                                    </div>
                                </div>
                            </div>
                            <div class="featured-icon-box icon-align-before-content icon-ver_align-top style1">
                                <div class="featured-icon">
                                    <div class="ttm-icon ttm-icon_element-onlytxt ttm-icon_element-color-skincolor ttm-icon_element-size-xs"> <i class="ti-location-pin"></i> </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-desc">
                                        <p>27b Abike Sulaiman, Lekki Phase 1 Lagos Nigeria</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Bottom footer -->
            <div class="bottom-footer-text">
                <div class="row copyright">
                    <div class="col-md-8">
                        <p class="mb-0">Copyright © 2022 (Virusshot) Design by <a href="https://makindeisaiah.com">MI Tech</a>. All rights reserved.</p>
                    </div>
                    <div class="col-md-4">
                        <div class="social-icons">
                            <ul class="list-inline">
                                <li><a href="https://web.facebook.com/ayomide.tanimowo"><i class="ti-facebook"></i></a></li>
                                <li><a href="https://www.instagram.com/virusshot/"><i class="ti-instagram"></i></a></li>
                                <li><a href="https://twitter.com/virusshot_"><i class="ti-twitter"></i></a></li>
                                <li><a href="#"><i class="ti-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>